- /`WHO'S YOUR DADDY CLASSIC SPEED HACK`\

\\ How To Enable It, Replace The <Assembly-CSharp-firstpass.dll> In The Folder `WhosYourDaddy_Data/Managed`
\\ Hack was made with DnSpy Editing The File

Note: `This may not work because it was not tested on a server where i am not a host, because no one plays classic anymore but test it with your friends to see if it works if your friend is the host`